package com.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Customers;
import com.service.CustomersService;

@RestController
public class CustomerController {
	
	@Autowired
	private CustomersService customersService;
	
	@GetMapping("/getAllCustomers")
	public List<Customers> getAllCustomers()
	{
		return customersService.getAllCustomers();
	}
	
	@PostMapping("/registerCustomer")
	public ResponseEntity<Customers> registerCustomer(@Valid @RequestBody Customers customers)
	{
		return new ResponseEntity<Customers>(customersService.registerCustomer(customers) , HttpStatus.CREATED);
	}
	
	@PutMapping("/updateCustomerById/{customerid}")
	public ResponseEntity<Customers> updateCustomer(@PathVariable("customerid") Integer customerid , @RequestBody Customers customer)
	{
		return new ResponseEntity<Customers>(customersService.updateCustomer(customerid,customer), HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteCustomerById/{customerid}")
	public ResponseEntity<String> deleteCustomerById(@PathVariable("customerid") Integer customerid)
	{
		customersService.deleteCustomerById(customerid);
		return new ResponseEntity<String>("Customer details deleted" , HttpStatus.OK);
	}

}
