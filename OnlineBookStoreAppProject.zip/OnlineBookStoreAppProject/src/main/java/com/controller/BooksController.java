package com.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.entity.Books;
import com.service.BooksService;

@RestController
public class BooksController {
	
	
	@Autowired
	private BooksService booksService;
	
	@GetMapping("/getAllBooks")
	public List<Books> getAllBooks()
	{
		return booksService.getAllBooks();
	}
	
	@PostMapping("/registerBook")
	public ResponseEntity<Books> registerBook(@Valid @RequestBody Books books)
	{
		return new ResponseEntity<Books>(booksService.registerBook(books), HttpStatus.CREATED);
	}
	
	@PutMapping("/updateBookById/{bookid}")
	public ResponseEntity<Books> updateBook(@PathVariable("bookid") Integer bookid, @RequestBody Books book)
	{
		return new ResponseEntity<Books>(booksService.updateBook(bookid,book),HttpStatus.OK);
		
	}
	
	
	@DeleteMapping("/deleteBookById/{bookid}")
	public ResponseEntity<String> deleteBookById(@PathVariable("bookid") Integer bookid)
	{
		booksService.deleteBookById(bookid);
		return new ResponseEntity<String>("Book record is deleted",HttpStatus.OK);
	}
	
	@PutMapping("/book/{bookid}/author/{authorid}")
	public ResponseEntity<Books> updateAuthorToBook(@PathVariable Integer bookid , @PathVariable Integer authorid)
	{
		return new ResponseEntity<Books>(booksService.updateAuthorToBook(bookid,authorid), HttpStatus.OK);
	}
	
	@PutMapping("/book/{bookid}/publisher/{publisherid}")
	public ResponseEntity<Books> updatePublisherToBook(@PathVariable Integer bookid , @PathVariable Integer publisherid)
	{
		return new ResponseEntity<Books>(booksService.updatePublisherToBook(bookid, publisherid) , HttpStatus.OK);
	}
	
	
	

	
}
