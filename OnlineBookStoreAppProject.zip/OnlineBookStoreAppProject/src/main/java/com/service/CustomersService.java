package com.service;

import java.util.List;

import com.entity.Customers;

public interface CustomersService {

	

	List<Customers> getAllCustomers();

	Customers registerCustomer(Customers customers);

	Customers updateCustomer(Integer customerid, Customers customer2);

	void deleteCustomerById(Integer customerid);

}
