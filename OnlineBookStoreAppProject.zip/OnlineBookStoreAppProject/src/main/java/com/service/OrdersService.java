package com.service;

import java.util.List;



import com.entity.Orders;

public interface OrdersService {

	List<Orders> getAllOrders();

	Orders placeNewOrder(Orders orders);

	Orders updateOrderDetails(Integer orderid, Orders order);

	void deleteOrderById(Integer orderid);

	Orders addBookToOrderList(Integer orderid, Integer bookid);

}
