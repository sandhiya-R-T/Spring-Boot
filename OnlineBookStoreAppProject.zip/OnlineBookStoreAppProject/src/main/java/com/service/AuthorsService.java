package com.service;

import java.util.List;

import com.entity.Authors;

public interface AuthorsService {

	List<Authors> getAllAuthors();

	Authors registerAuthor(Authors authors);

	void deleteAuthorById(Integer authorid);

	Authors updateAuthor(Integer authorid, Authors author);

	

}
