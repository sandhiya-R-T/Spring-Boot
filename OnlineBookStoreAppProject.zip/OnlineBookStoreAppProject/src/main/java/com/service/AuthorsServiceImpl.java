package com.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.entity.Authors;
import com.exception.ResourceNotFoundException;
import com.repository.AuthorsRepository;

@Service
public class AuthorsServiceImpl implements AuthorsService {

	@Autowired
	private AuthorsRepository authorsRepository;
	
	@Override
	public List<Authors> getAllAuthors() {
		
		return authorsRepository.findAll() ;
	}

	@Override
	public Authors registerAuthor(Authors authors) {
		
		return authorsRepository.save(authors);
	}

	@Override
	public void deleteAuthorById(Integer authorid) {
		Authors authors = authorsRepository.findById(authorid).get();
		if(authors != null)
		{
			authorsRepository.deleteById(authorid);
		}
		else
		{
		throw new ResourceNotFoundException("Authors", "Authorid", authorid);
		}
		
	}

	@Override
	public Authors updateAuthor(Integer authorid, Authors author) {
		Authors auth = authorsRepository.findById(authorid).get();
		Authors authdb = null;
		if(auth != null)
		{
			authdb = authorsRepository.findById(authorid).get();
			authdb.setFirstName(author.getFirstName());
			authdb.setLastName(author.getLastName());
			System.out.println(authdb);
			return authorsRepository.save(authdb);
		}
		else
		{
		throw new ResourceNotFoundException("Authors", "Authorid", authorid);
		}
		
	}

}
